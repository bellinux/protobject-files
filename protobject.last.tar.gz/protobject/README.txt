open terminal
go to this directory and execute: ./protobject

enjoy!
